# NFE Toolkit

Biblioteca para manipulação de arquivos nfe (Nota Fiscal Eletrônica)

## Requisitos

- python
- xsdata
- nfelib
- spedpy

## Como instalar

    $ pip install nfetoolkit

## Objetivos do Projeto

A ideia é criar um toolkit para leitura/criação/organização de xmls relacionados ao projeto da Nota Fiscal Eletrônica

